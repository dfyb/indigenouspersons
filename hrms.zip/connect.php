<?php
$Email $_POST
$Password $_POST
?>